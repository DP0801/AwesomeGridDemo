var awedict = {
    Empty: 'empty',
    GridInfo: "of {0} items",
    Select: 'please select',
    SearchForRes: 'search for more results',
    NoRecFound: 'no records found',
    PageSize: 'page size',
    Months: [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ],
    Days: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],

    Yes: 'Yes',
    No: 'No',
    Cancel: 'Cancel',
    Ok: 'Ok',
    GridGroupBar: 'Drag a column header and drop it here to group by that column',
    More: 'more',
    Search: 'Search',
    selected: 'selected'
};

//export {awedict};